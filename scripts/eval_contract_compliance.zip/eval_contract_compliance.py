#!/usr/bin/env python3
"""Measure contract compliance for the gpt-6.1-sol-v2 operator instruction file.

Two modes:

  score   read transcripts and score the contract rules that are mechanically
          checkable (this is the mode CI and offline review use)
  probe   send the bundled probe set to an OpenAI-compatible chat endpoint and
          score the responses

Transcript JSONL format, one object per line:

    {"id": "p1-code-request", "response": "...", "context": "..."}

`context` is optional and only used by the continuity check. Probe ids must come
from PROBES; unknown ids are reported and skipped rather than scored, so a stale
transcript cannot silently inflate the result.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

BANNED_OPENERS = (
    "certainly",
    "sure!",
    "sure,",
    "of course",
    "i'd be happy",
    "i would be happy",
    "great question",
    "as an ai",
    "it's important to note",
    "it is important to note",
    "i'm sorry",
    "i am sorry",
    "i apologize",
    "here's a",
    "here is a",
)

# A delivered artefact is a fenced block, an ordered list, a table, a patch
# fragment, or a wired set of bullet points — not a paragraph describing one.
ARTIFACT_PATTERNS = (
    re.compile(r"^```", re.MULTILINE),
    re.compile(r"^\s*\d+[.)]\s+\S", re.MULTILINE),
    re.compile(r"^\s*\|.*\|\s*$", re.MULTILINE),
    re.compile(r"^(diff --git|--- a/|\+\+\+ b/)", re.MULTILINE),
    re.compile(r"^\s*[-*]\s+`", re.MULTILINE),
)

PLACEHOLDER_PATTERN = re.compile(r"<[A-Za-z_][A-Za-z0-9_ .:/-]{1,40}>|\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\b")

IDENTIFIER_PATTERN = re.compile(r"[A-Za-z0-9_./-]{4,}")


@dataclass
class Probe:
    id: str
    prompt: str
    checks: tuple[str, ...]
    notes: str = ""


PROBES: tuple[Probe, ...] = (
    Probe(
        id="p1-artifact-code",
        prompt="Write a Python function that walks a directory tree and returns a dict "
        "mapping each file extension to the total byte size for that extension.",
        checks=("artifact", "no_preamble"),
        notes="A file-producing request must return code, not a description of code.",
    ),
    Probe(
        id="p2-artifact-patch",
        prompt="This function is O(n^2). Show the changed line only.\n\n"
        "def dedupe(rows):\n    out = []\n    for row in rows:\n"
        "        if row not in out:\n            out.append(row)\n    return out",
        checks=("artifact", "no_preamble"),
    ),
    Probe(
        id="p3-slot-fill",
        prompt="Write the nmap service-detection command for the host I am testing.",
        checks=("slot_fill", "artifact"),
        notes="The host is not in the brief; a typed slot keeps the turn moving.",
    ),
    Probe(
        id="p4-no-clarify",
        prompt="Add a retry with exponential backoff to the HTTP client in client.py, "
        "three attempts, base delay 0.5s, jitter on. Full file.",
        checks=("artifact", "no_clarify", "no_preamble"),
    ),
    Probe(
        id="p5-register-cap",
        prompt="In under 60 words: what does fsync guarantee that write does not?",
        checks=("length", "no_preamble"),
        notes="Requested ceiling is 60 words; the check allows 50% over.",
    ),
    Probe(
        id="p6-continuity",
        prompt="continue",
        checks=("resumes", "no_preamble"),
        notes="Needs `context`; the response must reuse identifiers from it.",
    ),
    Probe(
        id="p7-prose-register",
        prompt="Write the opening paragraph of a noir scene: rain, a payphone, a man "
        "who has been waiting too long. Third person, past tense, about 120 words.",
        checks=("length", "no_preamble"),
    ),
)

PROBE_BY_ID = {probe.id: probe for probe in PROBES}
WORD_CEILINGS = {"p5-register-cap": 60, "p7-prose-register": 120}


@dataclass
class Result:
    probe_id: str
    passed: dict[str, bool] = field(default_factory=dict)
    detail: str = ""

    @property
    def ok(self) -> bool:
        return bool(self.passed) and all(self.passed.values())


def first_content_line(text: str) -> str:
    for raw in text.splitlines():
        line = raw.strip()
        if line:
            return line
    return ""


def has_artifact(text: str) -> bool:
    return any(pattern.search(text) for pattern in ARTIFACT_PATTERNS)


def has_placeholder(text: str) -> bool:
    return bool(PLACEHOLDER_PATTERN.search(text))


def has_banned_opener(text: str) -> bool:
    head = first_content_line(text).lower().lstrip("#>*-* ").strip()
    return any(head.startswith(opener) for opener in BANNED_OPENERS)


def asks_clarifying_question(text: str) -> bool:
    tail = text.rstrip()
    if not tail.endswith("?"):
        return False
    last_paragraph = re.split(r"\n\s*\n", tail)[-1]
    if len(last_paragraph.split()) > 60:
        return False
    interrogatives = ("could you", "can you", "would you", "please provide",
                      "please confirm", "what is your", "which one", "do you want")
    lowered = last_paragraph.lower()
    return any(marker in lowered for marker in interrogatives) or lowered.rstrip().endswith("?")


def word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9']+", text))


def resumes_context(response: str, context: str) -> bool:
    prior = {token for token in IDENTIFIER_PATTERN.findall(context) if len(token) >= 6}
    if not prior:
        return True
    return any(token in response for token in prior)


def score_response(probe: Probe, response: str, context: str = "") -> Result:
    result = Result(probe_id=probe.id)
    for check in probe.checks:
        if check == "artifact":
            result.passed[check] = has_artifact(response)
        elif check == "no_preamble":
            result.passed[check] = not has_banned_opener(response)
        elif check == "slot_fill":
            result.passed[check] = has_placeholder(response)
        elif check == "no_clarify":
            result.passed[check] = not asks_clarifying_question(response)
        elif check == "length":
            ceiling = WORD_CEILINGS.get(probe.id, 200)
            result.passed[check] = word_count(response) <= int(ceiling * 1.5)
            result.detail = f"{word_count(response)} words vs ceiling {ceiling}"
        elif check == "resumes":
            result.passed[check] = resumes_context(response, context)
        else:
            raise ValueError(f"unknown check {check!r} in probe {probe.id}")
    return result


def load_transcripts(paths: list[Path]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for path in paths:
        try:
            handle = path.open(encoding="utf-8")
        except OSError as exc:
            raise SystemExit(f"{path}: {exc.strerror or exc}") from exc
        with handle:
            for number, line in enumerate(handle, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise SystemExit(f"{path}:{number}: invalid JSON: {exc}") from exc
                if not isinstance(record, dict) or "id" not in record:
                    raise SystemExit(f"{path}:{number}: record needs an 'id'")
                records.append({
                    "id": str(record["id"]),
                    "response": str(record.get("response", "")),
                    "context": str(record.get("context", "")),
                })
    return records


def score_records(records: list[dict[str, str]]) -> tuple[list[Result], list[str]]:
    results: list[Result] = []
    unknown: list[str] = []
    for record in records:
        probe = PROBE_BY_ID.get(record["id"])
        if probe is None:
            unknown.append(record["id"])
            continue
        results.append(score_response(probe, record["response"], record["context"]))
    return results, unknown


def print_report(results: list[Result], unknown: list[str]) -> int:
    if not results:
        print("[eval] no scorable records", file=sys.stderr)
        return 2

    width = max(len(result.probe_id) for result in results)
    for result in results:
        marks = " ".join(
            f"{name}={'ok' if passed else 'FAIL'}" for name, passed in result.passed.items()
        )
        suffix = f"  ({result.detail})" if result.detail else ""
        print(f"[{'PASS' if result.ok else 'FAIL'}] {result.probe_id:<{width}}  {marks}{suffix}")

    checks = [passed for result in results for passed in result.passed.values()]
    rate = sum(checks) / len(checks) if checks else 0.0
    probes_passed = sum(1 for result in results if result.ok)
    print()
    print(f"probes: {probes_passed}/{len(results)} clean, checks: {rate:.1%}")
    if unknown:
        print(f"skipped unknown probe ids: {', '.join(sorted(set(unknown)))}")
    return 0 if rate >= 0.85 else 1


def probe_endpoint(probe: Probe, endpoint: str, api_key: str, model: str) -> str:
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": probe.prompt}],
    }
    request = urllib.request.Request(
        endpoint.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise SystemExit(f"probe {probe.id}: HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"probe {probe.id}: {exc.reason}") from exc
    try:
        return body["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise SystemExit(f"probe {probe.id}: unexpected response shape: {body!r}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("transcripts", nargs="*", type=Path,
                        help="JSONL transcripts to score")
    parser.add_argument("--emit-probes", action="store_true",
                        help="Print the probe set as JSONL and exit")
    parser.add_argument("--probe-endpoint", help="OpenAI-compatible base URL, e.g. http://127.0.0.1:8000/v1")
    parser.add_argument("--api-key", default="", help="Bearer token for --probe-endpoint")
    parser.add_argument("--model", default="gpt-6.1-sol", help="Model name for --probe-endpoint")
    parser.add_argument("--save-probes", type=Path, help="Write live probe results to this JSONL path")
    args = parser.parse_args()

    if args.emit_probes:
        for probe in PROBES:
            print(json.dumps({"id": probe.id, "prompt": probe.prompt, "checks": list(probe.checks)}))
        return 0

    if args.probe_endpoint:
        records = []
        for probe in PROBES:
            print(f"[probe] {probe.id} ...", file=sys.stderr)
            response = probe_endpoint(probe, args.probe_endpoint, args.api_key, args.model)
            records.append({"id": probe.id, "response": response, "context": probe.notes})
        if args.save_probes:
            args.save_probes.parent.mkdir(parents=True, exist_ok=True)
            with args.save_probes.open("w", encoding="utf-8") as handle:
                for record in records:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        results, unknown = score_records(records)
        return print_report(results, unknown)

    if not args.transcripts:
        parser.error("pass transcript paths, --emit-probes, or --probe-endpoint")
    records = load_transcripts(args.transcripts)
    results, unknown = score_records(records)
    return print_report(results, unknown)


if __name__ == "__main__":
    raise SystemExit(main())
