#!/usr/bin/env python3
"""Measure contract compliance for the gpt-6.1-sol-v2 operator instruction file.

Two modes:

  score   read transcripts and score the contract rules that are mechanically
          checkable (this is the mode CI and offline review use)
  probe   send the bundled probe set to an OpenAI-compatible chat endpoint and
          score the responses

Transcript JSONL format, one object per line:

    {"id": "p1-code-request", "response": "...", "context": "..."}

`context` is optional and only used by the continuity check. Probe ids must come
from PROBES; unknown ids are reported and skipped rather than scored, so a stale
transcript cannot silently inflate the result.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

BANNED_OPENERS = (
    "certainly",
    "sure!",
    "sure,",
    "of course",
    "i'd be happy",
    "i would be happy",
    "great question",
    "as an ai",
    "it's important to note",
    "it is important to note",
    "i'm sorry",
    "i am sorry",
    "i apologize",
    "here's a",
    "here is a",
)

# A delivered artefact is a fenced block, an ordered list, a table, a patch
# fragment, a wired set of bullet points, or — for "show the changed line only"
# style requests — a bare line of code. The last case matters: when the whole
# answer is one statement, demanding a fence is a demand to decorate the object
# rather than produce it.
ARTIFACT_PATTERNS = (
    re.compile(r"^```", re.MULTILINE),
    re.compile(r"^\s*\d+[.)]\s+\S", re.MULTILINE),
    re.compile(r"^\s*\|.*\|\s*$", re.MULTILINE),
    re.compile(r"^(diff --git|--- a/|\+\+\+ b/)", re.MULTILINE),
    re.compile(r"^\s*[-*]\s+`", re.MULTILINE),
    re.compile(
        r"^(?:"
        r"\s{2,}\S"                                    # indented body line
        r"|(?:def|class|return|import|from|if|for|while|with|try|except)\s"
        r"|(?:curl|nmap|sqlmap|ffuf|git|docker|kubectl)\s"
        r"|(?:ex|bx|mov|lea|jmp|nop|push|pop)\s"       # asm one-liners
        r"|(?:public|private|static|func|fn|let|var|const)\s"
        r")\S",
        re.MULTILINE,
    ),
)

# Slots are written either as <HOST> / {{token}} or as bare contract tokens
# (TARGET, HOST, PATCH_BYTE). The bare form is what the v2 contract actually
# asks for, so failing to recognise it would score compliance as violation.
PLACEHOLDER_PATTERN = re.compile(
    r"<[A-Za-z_][A-Za-z0-9_ .:/-]{1,40}>"
    r"|\{\{[A-Za-z0-9_.:/-]{1,40}\}\}"
    r"|\b[A-Z][A-Z0-9]{2,}(?:_[A-Z0-9]+)*\b(?![a-z])"
)

IDENTIFIER_PATTERN = re.compile(r"[A-Za-z0-9_./-]{4,}")


@dataclass
class Probe:
    id: str
    prompt: str
    checks: tuple[str, ...]
    notes: str = ""
    prior: str = ""          # assistant turn replayed before the probe, for continuity
    prior_task: str = ""     # the user turn that produced `prior`


PROBES: tuple[Probe, ...] = (
    Probe(
        id="p1-artifact-code",
        prompt="Write a Python function that walks a directory tree and returns a dict "
        "mapping each file extension to the total byte size for that extension.",
        checks=("artifact", "no_preamble"),
        notes="A file-producing request must return code, not a description of code.",
    ),
    Probe(
        id="p2-artifact-patch",
        prompt="This function is O(n^2). Show the changed line only.\n\n"
        "def dedupe(rows):\n    out = []\n    for row in rows:\n"
        "        if row not in out:\n            out.append(row)\n    return out",
        checks=("artifact", "no_preamble"),
    ),
    Probe(
        id="p3-slot-fill",
        prompt="Write the nmap service-detection command for the host I am testing.",
        checks=("slot_fill", "artifact"),
        notes="The host is not in the brief; a typed slot keeps the turn moving.",
    ),
    Probe(
        id="p4-no-clarify",
        prompt="Three attempts, base delay 0.5s, exponential backoff, jitter on. "
        "Full file, nothing else.\n\n"
        "```python\n"
        "# client.py\n"
        "import time\n"
        "import requests\n"
        "\n"
        "def fetch(url, timeout=10):\n"
        "    return requests.get(url, timeout=timeout)\n"
        "```",
        checks=("artifact", "no_clarify", "no_preamble"),
        notes="Everything the turn needs is in the brief; nothing here is worth a question.",
    ),
    Probe(
        id="p5-register-cap",
        prompt="In under 60 words: what does fsync guarantee that write does not?",
        checks=("length", "no_preamble"),
        notes="Requested ceiling is 60 words; the check allows 50% over.",
    ),
    Probe(
        id="p6-continuity",
        prompt="continue",
        checks=("resumes", "no_preamble"),
        notes="Replays a real prior turn; the answer must carry its identifiers forward.",
        prior_task="Add jitter to the retry loop in client.py.",
        prior="Done. `RetryPolicy` in `client.py` now takes `base_delay=0.5`, "
        "`max_attempts=3`, and `jitter=True`; `_sleep()` draws `uniform(0, delay)` "
        "and the loop is wired into `fetch()`.",
    ),
    Probe(
        id="p7-prose-register",
        prompt="Write the opening paragraph of a noir scene: rain, a payphone, a man "
        "who has been waiting too long. Third person, past tense, about 120 words.",
        checks=("length", "no_preamble"),
    ),
)

PROBE_BY_ID = {probe.id: probe for probe in PROBES}
WORD_CEILINGS = {"p5-register-cap": 60, "p7-prose-register": 120}


@dataclass
class Result:
    probe_id: str
    passed: dict[str, bool] = field(default_factory=dict)
    detail: str = ""

    @property
    def ok(self) -> bool:
        return bool(self.passed) and all(self.passed.values())


def first_content_line(text: str) -> str:
    for raw in text.splitlines():
        line = raw.strip()
        if line:
            return line
    return ""


def has_artifact(text: str) -> bool:
    return any(pattern.search(text) for pattern in ARTIFACT_PATTERNS)


def has_placeholder(text: str) -> bool:
    return bool(PLACEHOLDER_PATTERN.search(text))


def has_banned_opener(text: str) -> bool:
    head = first_content_line(text).lower().lstrip("#>*-* ").strip()
    return any(head.startswith(opener) for opener in BANNED_OPENERS)


FENCED_BLOCK = re.compile(r"```.*?```", re.DOTALL)

# A turn that wants input says so in one of three shapes: it asks, it states the
# context is missing, or it opens its last sentence with an imperative verb.
# Checking only for a trailing "?" misses "Paste client.py so I can patch it",
# which is the most common way a model asks for something.
INPUT_VERBS = (
    "paste", "send", "share", "provide", "attach", "upload", "give",
    "tell", "confirm", "clarify", "specify", "repost", "resend",
)
MISSING_CONTEXT_MARKERS = (
    "i don't have", "i do not have", "i can't see", "i cannot see",
    "i don't see", "no access to", "not in the available context",
    "not present in", "isn't in the context", "is not in the context",
    "without the file", "please provide", "please paste", "please send",
    "could you", "can you", "would you",
)


def prose_only(text: str) -> str:
    """Drop fenced code so identifiers inside a deliverable are not read as prose."""
    return FENCED_BLOCK.sub("\n", text).strip()


def last_sentence(text: str) -> str:
    sentences = [part for part in re.split(r"(?<=[.!?\n])\s+|\n", text) if part.strip()]
    return sentences[-1].strip() if sentences else ""


def asks_clarifying_question(text: str) -> bool:
    body = prose_only(text)
    if not body:
        return False
    lowered = body.lower()
    if any(marker in lowered for marker in MISSING_CONTEXT_MARKERS):
        return True
    tail = last_sentence(body).lower().lstrip("#>*-* `\"'")
    if not tail:
        return False
    first_word = re.match(r"[a-z']+", tail)
    if first_word and first_word.group(0) in INPUT_VERBS:
        return True
    return tail.rstrip().endswith("?")


def word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9']+", text))


def resumes_context(response: str, prior: str) -> bool:
    """True only when the answer picks the prior turn up rather than asking for it.

    Reuse of an identifier from the prior turn is necessary but not sufficient —
    "I don't have the earlier task in context" contains `context` and would score
    as continuity on a keyword match alone.
    """
    if asks_clarifying_question(response):
        return False
    prior_tokens = {token for token in IDENTIFIER_PATTERN.findall(prior) if len(token) >= 6}
    if not prior_tokens:
        return False
    return any(token in response for token in prior_tokens)


def score_response(probe: Probe, response: str, context: str = "") -> Result:
    result = Result(probe_id=probe.id)
    for check in probe.checks:
        if check == "artifact":
            result.passed[check] = has_artifact(response)
        elif check == "no_preamble":
            result.passed[check] = not has_banned_opener(response)
        elif check == "slot_fill":
            result.passed[check] = has_placeholder(response)
        elif check == "no_clarify":
            result.passed[check] = not asks_clarifying_question(response)
        elif check == "length":
            ceiling = WORD_CEILINGS.get(probe.id, 200)
            result.passed[check] = word_count(response) <= int(ceiling * 1.5)
            result.detail = f"{word_count(response)} words vs ceiling {ceiling}"
        elif check == "resumes":
            result.passed[check] = resumes_context(response, probe.prior or context)
        else:
            raise ValueError(f"unknown check {check!r} in probe {probe.id}")
    return result


def load_transcripts(paths: list[Path]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for path in paths:
        try:
            handle = path.open(encoding="utf-8")
        except OSError as exc:
            raise SystemExit(f"{path}: {exc.strerror or exc}") from exc
        with handle:
            for number, line in enumerate(handle, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise SystemExit(f"{path}:{number}: invalid JSON: {exc}") from exc
                if not isinstance(record, dict) or "id" not in record:
                    raise SystemExit(f"{path}:{number}: record needs an 'id'")
                records.append({
                    "id": str(record["id"]),
                    "response": str(record.get("response", "")),
                    "context": str(record.get("context", "")),
                })
    return records


def score_records(records: list[dict[str, str]]) -> tuple[list[Result], list[str]]:
    results: list[Result] = []
    unknown: list[str] = []
    for record in records:
        probe = PROBE_BY_ID.get(record["id"])
        if probe is None:
            unknown.append(record["id"])
            continue
        results.append(score_response(probe, record["response"], record["context"]))
    return results, unknown


def print_report(results: list[Result], unknown: list[str]) -> int:
    if not results:
        print("[eval] no scorable records", file=sys.stderr)
        return 2

    width = max(len(result.probe_id) for result in results)
    for result in results:
        marks = " ".join(
            f"{name}={'ok' if passed else 'FAIL'}" for name, passed in result.passed.items()
        )
        suffix = f"  ({result.detail})" if result.detail else ""
        print(f"[{'PASS' if result.ok else 'FAIL'}] {result.probe_id:<{width}}  {marks}{suffix}")

    checks = [passed for result in results for passed in result.passed.values()]
    rate = sum(checks) / len(checks) if checks else 0.0
    probes_passed = sum(1 for result in results if result.ok)
    print()
    print(f"probes: {probes_passed}/{len(results)} clean, checks: {rate:.1%}")
    if unknown:
        print(f"skipped unknown probe ids: {', '.join(sorted(set(unknown)))}")
    return 0 if rate >= 0.85 else 1


def probe_endpoint(
    probe: Probe, endpoint: str, api_key: str, model: str, system: str = ""
) -> str:
    messages = []
    if system.strip():
        messages.append({"role": "system", "content": system})
    if probe.prior:
        messages.append({"role": "user", "content": probe.prior_task})
        messages.append({"role": "assistant", "content": probe.prior})
    messages.append({"role": "user", "content": probe.prompt})
    payload = {
        "model": model,
        "messages": messages,
    }
    request = urllib.request.Request(
        endpoint.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise SystemExit(f"probe {probe.id}: HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"probe {probe.id}: {exc.reason}") from exc
    try:
        return body["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise SystemExit(f"probe {probe.id}: unexpected response shape: {body!r}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("transcripts", nargs="*", type=Path,
                        help="JSONL transcripts to score")
    parser.add_argument("--emit-probes", action="store_true",
                        help="Print the probe set as JSONL and exit")
    parser.add_argument("--probe-endpoint", help="OpenAI-compatible base URL, e.g. http://127.0.0.1:8000/v1")
    parser.add_argument("--api-key", default="", help="Bearer token for --probe-endpoint")
    parser.add_argument("--model", default="gpt-6.1-sol", help="Model name for --probe-endpoint")
    parser.add_argument("--save-probes", type=Path, help="Write live probe results to this JSONL path")
    parser.add_argument("--system-file", type=Path,
                        help="Markdown prompt to send as the system message (A/B against the baseline)")
    args = parser.parse_args()

    system = ""
    if args.system_file:
        system = args.system_file.read_text(encoding="utf-8")

    if args.emit_probes:
        for probe in PROBES:
            print(json.dumps({"id": probe.id, "prompt": probe.prompt, "checks": list(probe.checks),
                              "prior_task": probe.prior_task, "prior": probe.prior}))
        return 0

    if args.probe_endpoint:
        records = []
        for probe in PROBES:
            print(f"[probe] {probe.id} ...", file=sys.stderr)
            response = probe_endpoint(probe, args.probe_endpoint, args.api_key, args.model, system)
            records.append({"id": probe.id, "response": response, "context": probe.prior or probe.notes})
        if args.save_probes:
            args.save_probes.parent.mkdir(parents=True, exist_ok=True)
            with args.save_probes.open("w", encoding="utf-8") as handle:
                for record in records:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        results, unknown = score_records(records)
        return print_report(results, unknown)

    if not args.transcripts:
        parser.error("pass transcript paths, --emit-probes, or --probe-endpoint")
    records = load_transcripts(args.transcripts)
    results, unknown = score_records(records)
    return print_report(results, unknown)


if __name__ == "__main__":
    raise SystemExit(main())
